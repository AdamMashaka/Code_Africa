import React from "react";
import LOGINPAGEPage from "./LOGINPAGE";
const Home = () => {
  return (
    <LOGINPAGEPage/>
  );
};
export default Home;
