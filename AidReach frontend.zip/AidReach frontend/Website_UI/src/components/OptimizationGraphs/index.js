import RolesPerPeople from "./RolesPerPeople"
export  {RolesPerPeople}