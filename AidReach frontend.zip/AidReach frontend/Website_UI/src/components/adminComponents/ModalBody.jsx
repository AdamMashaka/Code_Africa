import React from "react";


export default function ModalBody({ children }) {
  return <div className="px-6 mt-2">{children}</div>;
}
