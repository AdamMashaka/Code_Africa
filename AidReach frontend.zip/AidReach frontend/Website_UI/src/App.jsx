import React from "react";
import Routes from "./Routes";
import Error from "components/Errors";
function App() {
  return (
    <>
      <Routes />
    </>
  )
}

export default App;
